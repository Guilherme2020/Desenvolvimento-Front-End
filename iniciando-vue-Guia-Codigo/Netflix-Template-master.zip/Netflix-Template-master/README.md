# Netflix-Template
Tema semelhante ao Netflix com Javascript e CSS. Você pode ajudar contribuindo com mais recursos e melhorias.

## Video
https://youtu.be/qBNOBIU5j0o
